import { useState, useEffect } from "react";
import { motion } from "framer-motion";

import Controls from "./components/controls";
import { projects } from "./components/projectdata";
import type { Project } from "./components/projectdata";
import { ProjectCard } from "./components/projectcard";

export default function ProjectList() {
   const [search, setSearch] = useState<string>("");
   const [filter, setFilter] = useState<string>("All");
   const [filteredProjects, setFilteredProjects] = useState<Project[]>(projects);

   useEffect(() => {
      setFilteredProjects(projects.filter((p) => (filter === "All" || p.categories.includes(filter)) && p.title.toLowerCase().includes(search.toLowerCase())));
   }, [search, filter]);

   return (
      <section className="container mx-auto px-18 pt-36 space-y-12">
         <Controls searchValue={search} onSearchChange={setSearch} selectedFilter={filter} onFilterChange={setFilter} />

         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project, idx) => (
               <motion.div key={project.title} initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: idx * 0.1 }} viewport={{ once: true, amount: 0.2 }} className="w-full">
                  <ProjectCard project={project} />
               </motion.div>
            ))}
         </div>
      </section>
   );
}
